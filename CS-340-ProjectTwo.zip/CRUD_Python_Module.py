# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pymongo.errors import PyMongoError

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'password' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            try:
                result = self.collection.insert_one(data)  # data should be dictionary 
                return True
            except PyMongoError as e:
                print("Creation Error:", e)
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Method to implement the R in CRUD. 
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            results = list(cursor)
            return results
        except PyMongoError as e:
            print("Read Error:", e)
            return []
        
    # Method to implement the U in CRUD
    def update(self, query, new_values):
        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count
        except PyMongoError as e:
            print("Update Error:", e)
            return 0
    
    # Method to implement the D in CRUD
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print("Delete Error:", e)
            return 0